package com.DCSApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DCSApplication {

	public static void main(String[] args) {
		SpringApplication.run(DCSApplication.class, args);
		System.err.println("Dental Care Services is Runnnnnnnnning.............");
	}

}
